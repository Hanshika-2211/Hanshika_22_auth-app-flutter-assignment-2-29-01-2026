package com.example.frontend

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
